from django.apps import AppConfig


class RatingsAppConfig(AppConfig):
    name = 'ratings_app'
