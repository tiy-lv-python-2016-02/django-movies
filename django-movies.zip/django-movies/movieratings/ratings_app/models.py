from django.db import models


    # Create Django models to represent the data.
    # Make sure that the data has the appropriate data
    # types. For simplicity sake you may skip the
    # genre_movies table and skip the many to many
    # relationship between movie and genre.

class Movie(models.Model):

    title = models.CharField(max_length=200)
    genres = models.CharField(max_length=200)

    # Make sure each model has 2 additional fields
    # to track the date added and the date modified.

    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)

class Genre(models.Model):
    genres = models.CharField(max_length=200)

    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)

class Link(models.Model):
    imdbid = models.SmallIntegerField()
    tmdbid = models.SmallIntegerField()

    movie = models.ForeignKey(Movie)

    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)

class Rating(models.Model):
    userid = models.IntegerField()
    rating = models.FloatField()

    movie = models.ForeignKey(Movie)

    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)

class Tag(models.Model):

    userid = models.IntegerField()
    tag = models.CharField(max_length=100)

    movie = models.ForeignKey(Movie)

    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)